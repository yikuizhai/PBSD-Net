import os
import cv2
import numpy as np
import json
from tqdm import tqdm
from shapely.geometry import Polygon

def crop(img, label_path, save_dir, save_name, crop_size=(512, 512), gap=(512, 512), ratio=0.2):
    with open(label_path, 'r') as json_file:
        original_json_data = json.load(json_file)

    h, w, _ = img.shape
    gp_w, gp_h = int(gap[0] * ratio), int(gap[1] * ratio)
    cp_w, cp_h = crop_size
    num = 0

    for j in range(0, h, gp_h):
        if j + cp_h > h + 100: continue
        for i in range(0, w, gp_w):
            if i + cp_w >= w + 100: continue

            cp_img = img[j:j+cp_h, i:i+cp_w]
            if np.sum(cp_img) > cp_w * cp_h * 255 * ratio:
                left, top = i, j
                right, bottom = left + cp_w, top + cp_h
                small_json_data = original_json_data.copy()
                shapes_to_keep = []

                for shape in small_json_data["shapes"]:
                    polygon = Polygon(shape["points"]).buffer(0)
                    intersection = polygon.intersection(Polygon([(left, top), (right, top), (right, bottom), (left, bottom)]))

                    if not intersection.is_empty:
                        if intersection.geom_type in ["MultiPolygon", "Polygon"]:
                            for part in (intersection.geoms if intersection.geom_type == "MultiPolygon" else [intersection]):
                                if not part.is_empty:
                                    intersection_points = np.array(part.exterior.coords.xy).T[:-1] if part.geom_type == "Polygon" else np.array(part.coords.xy).T[:-1]
                                    intersection_points -= [left, top]
                                    shapes_to_keep.append({"label": shape["label"], "points": intersection_points.tolist()})

                if shapes_to_keep:
                    small_json_data["shapes"] = shapes_to_keep
                    small_json_data.update({
                        "imageData": None,
                        "imagePath": f"{save_name.replace('.jpg', f'_{num}.jpg')}",
                        "imageHeight": cp_h,
                        "imageWidth": cp_w
                    })

                    # 保存更新后的 JSON 数据
                    small_json_name = os.path.join(save_dir, save_name.replace('.jpg', f'_{num}.json'))
                    with open(small_json_name, 'w') as small_json_file:
                        json.dump(small_json_data, small_json_file)

                    # 保存裁剪出的图片
                    cv2.imwrite(os.path.join(save_dir, save_name.replace('.jpg', f'_{num}.jpg')), cp_img)
                    num += 1

if __name__ == '__main__':
    label_dir = r' ' #labelme标注的json文件存放路径
    img_dir = r'  ' #原图存放路径
    save_dir = r' ' 

    os.makedirs(save_dir, exist_ok=True)
    crop_size = (512, 512)
    ratio = 0.2
    gap = crop_size  # 滑动间隔等于裁剪尺寸

    for img_name in tqdm(os.listdir(img_dir)):
        label_name = os.path.splitext(img_name)[0] + '.json'
        label_path = os.path.join(label_dir, label_name)
        img_path = os.path.join(img_dir, img_name)

        if os.path.exists(label_path):
            img = cv2.imread(img_path, cv2.IMREAD_COLOR)
            crop(img, label_path, save_dir, img_name, crop_size=crop_size, gap=gap, ratio=ratio)
